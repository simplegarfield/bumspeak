-- WKLEJ TO W SUPABASE SQL EDITOR I KLIKNIJ RUN
-- Bezpiecznie dodaje brakujące kolumny i polityki

ALTER TABLE users    ADD COLUMN IF NOT EXISTS avatar_url  TEXT;
ALTER TABLE users    ADD COLUMN IF NOT EXISTS is_admin    BOOLEAN DEFAULT FALSE;
ALTER TABLE messages ADD COLUMN IF NOT EXISTS attachment_url TEXT;

-- Polityki (bezpieczne - nie wyrzucą błędu jeśli już istnieją)
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='users' AND policyname='public_update_users') THEN
    EXECUTE 'CREATE POLICY public_update_users ON users FOR UPDATE USING (true)';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='messages' AND policyname='public_delete_messages') THEN
    EXECUTE 'CREATE POLICY public_delete_messages ON messages FOR DELETE USING (true)';
  END IF;
END $$;

-- Ustaw tescik jako admina (jeśli już istnieje w bazie)
UPDATE users SET is_admin = TRUE WHERE lower(nick) = 'tescik';

-- Supabase Storage bucket na załączniki (uruchom tylko raz)
INSERT INTO storage.buckets (id, name, public)
VALUES ('attachments', 'attachments', true)
ON CONFLICT (id) DO NOTHING;

-- Polityki storage
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='storage' AND policyname='allow_upload') THEN
    EXECUTE 'CREATE POLICY allow_upload ON storage.objects FOR INSERT WITH CHECK (bucket_id = ''attachments'')';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='storage' AND policyname='allow_read') THEN
    EXECUTE 'CREATE POLICY allow_read ON storage.objects FOR SELECT USING (bucket_id = ''attachments'')';
  END IF;
END $$;
